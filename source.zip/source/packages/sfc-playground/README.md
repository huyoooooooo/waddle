# SFC Playground

This is continuously deployed at [https://play.vuejs.org](https://play.vuejs.org).

## Run Locally in Dev

In repo root:

```sh
pnpm dev-sfc
```

## Build for Prod

In repo root

```sh
pnpm build-sfc-playground
```
