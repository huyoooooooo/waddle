// serve vue to the iframe sandbox during dev.
// @ts-expect-error
export * from 'vue/dist/vue.runtime.esm-browser.prod.js'
