module.exports = require('@vue/compiler-sfc')

require('./register-ts.js')
