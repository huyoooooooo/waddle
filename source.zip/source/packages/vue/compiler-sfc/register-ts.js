if (typeof require !== 'undefined') {
  require('@vue/compiler-sfc').registerTS(() => require('typescript'))
}
