export * from '@vue/compiler-sfc'

import './register-ts.js'
