## Template Explorer

Live explorer for template compilation output.

To run:

- `npm run dev-compiler` in repo root
- When the compilation is done, in another terminal run `npm run open`

Note: `index.html` uses CDN for dependencies and is continuously deployed at [https://template-explorer.vuejs.org](https://template-explorer.vuejs.org). For local development, use the scripts above.
